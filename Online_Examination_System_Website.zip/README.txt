ONLINE EXAMINATION SYSTEM - DEMO

This is a working front-end prototype for your Java project presentation.

Demo Teacher Login:
Username: teacher
Password: 1234

Demo Student Login:
Username: student
Password: 1234

Features:
- Teacher dashboard
- Add/delete MCQ questions
- Student login
- Exam with 10-minute timer
- Automatic evaluation
- Percentage calculation
- Teacher result table
- Data persists in browser localStorage

IMPORTANT:
This version runs directly in a browser and is intended as the UI/prototype.
For the final Java college project, connect these pages to Java Servlet/JSP + MySQL so
teacher/student data is stored on the server/database rather than localStorage.
