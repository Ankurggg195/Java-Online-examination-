const KEY="examPortalData";
let data=JSON.parse(localStorage.getItem(KEY)||"null")||{
 questions:[
  {id:1,q:"Which language is primarily used for Android development in this project?",a:"Java",b:"HTML",c:"SQL",d:"CSS",correct:"A"},
  {id:2,q:"Which database is commonly used with Java web applications?",a:"MySQL",b:"Paint",c:"Photoshop",d:"Notepad",correct:"A"},
  {id:3,q:"What does API stand for?",a:"Application Programming Interface",b:"Applied Program Internet",c:"Application Page Input",d:"Advanced Program Index",correct:"A"}
 ],
 students:[{username:"student",password:"1234",name:"Demo Student"}],
 results:[]
};
let role="", currentStudent="", timerId=null, remaining=600, submitted=false;

function save(){localStorage.setItem(KEY,JSON.stringify(data));}
function qs(id){return document.getElementById(id)}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));qs(id).classList.add("active");window.scrollTo(0,0)}
function showHome(){show("home");refreshHome()}
function openLogin(r){role=r;qs("loginTitle").textContent=r==="teacher"?"Teacher Login":"Student Login";qs("loginHint").textContent=r==="teacher"?"Login to manage questions and view all results.":"Login to take the available exam.";qs("loginUser").value="";qs("loginPass").value="";qs("loginMsg").textContent="";show("login")}
function login(){
 const u=qs("loginUser").value.trim(), p=qs("loginPass").value;
 if(role==="teacher" && u==="teacher" && p==="1234"){showTeacher();return}
 const s=data.students.find(x=>x.username===u&&x.password===p);
 if(role==="student"&&s){currentStudent=s.name;showStudent();return}
 qs("loginMsg").textContent="Invalid username or password.";
}
function logout(){role="";currentStudent="";clearInterval(timerId);showHome()}
function refreshHome(){qs("homeQuestions").textContent=data.questions.length;qs("homeStudents").textContent=data.students.length;qs("homeResults").textContent=data.results.length}
function showTeacher(){show("teacher");refreshTeacher()}
function refreshTeacher(){
 qs("tQuestions").textContent=data.questions.length;qs("tStudents").textContent=data.students.length;qs("tResults").textContent=data.results.length;
 qs("questionList").innerHTML=data.questions.length?data.questions.map((x,i)=>`<div class="question-item"><button class="delete" onclick="deleteQuestion(${x.id})">Delete</button><b>Q${i+1}. ${escapeHtml(x.q)}</b><br><small>A. ${escapeHtml(x.a)} &nbsp; B. ${escapeHtml(x.b)} &nbsp; C. ${escapeHtml(x.c)} &nbsp; D. ${escapeHtml(x.d)}<br>Correct: ${x.correct}</small></div>`).join(""):"No questions yet.";
 qs("resultTable").innerHTML=data.results.length?data.results.map(r=>`<tr><td>${escapeHtml(r.student)}</td><td>${r.score}/${r.total}</td><td>${r.percentage}%</td><td>${r.date}</td></tr>`).join(""):`<tr><td colspan="4">No results yet.</td></tr>`;
}
function addQuestion(){
 const q=qs("qText").value.trim(), a=qs("optA").value.trim(),b=qs("optB").value.trim(),c=qs("optC").value.trim(),d=qs("optD").value.trim();
 if(!q||!a||!b||!c||!d){qs("qMsg").textContent="Please fill all fields.";return}
 data.questions.push({id:Date.now(),q,a,b,c,d,correct:qs("correct").value});save();
 ["qText","optA","optB","optC","optD"].forEach(id=>qs(id).value="");qs("qMsg").textContent="Question added successfully.";refreshTeacher();refreshHome();
}
function deleteQuestion(id){data.questions=data.questions.filter(x=>x.id!==id);save();refreshTeacher();refreshHome()}
function showStudent(){show("student");qs("studentWelcome").textContent=`Welcome, ${currentStudent}`;qs("studentStart").classList.remove("hidden");qs("examBox").classList.add("hidden");qs("studentResult").classList.add("hidden")}
function startExam(){
 if(!data.questions.length){alert("No questions available.");return}
 submitted=false;remaining=600;qs("studentStart").classList.add("hidden");qs("studentResult").classList.add("hidden");qs("examBox").classList.remove("hidden");
 qs("examQuestions").innerHTML=data.questions.map((x,i)=>`<div class="exam-q"><p>${i+1}. ${escapeHtml(x.q)}</p>${["A","B","C","D"].map(k=>`<label class="option"><input type="radio" name="q${x.id}" value="${k}">${k}. ${escapeHtml(x[k.toLowerCase()])}</label>`).join("")}</div>`).join("");
 updateTimer();clearInterval(timerId);timerId=setInterval(()=>{remaining--;updateTimer();if(remaining<=0){clearInterval(timerId);submitExam(true)}},1000);
}
function updateTimer(){const m=String(Math.floor(remaining/60)).padStart(2,"0"),s=String(remaining%60).padStart(2,"0");qs("timer").textContent=`${m}:${s}`}
function submitExam(auto=false){
 if(submitted)return;submitted=true;clearInterval(timerId);let score=0;
 data.questions.forEach(x=>{const el=document.querySelector(`input[name="q${x.id}"]:checked`);if(el&&el.value===x.correct)score++});
 const pct=Math.round(score/data.questions.length*100);
 data.results.push({student:currentStudent,score,total:data.questions.length,percentage:pct,date:new Date().toLocaleString()});save();
 qs("examBox").classList.add("hidden");qs("studentResult").classList.remove("hidden");qs("studentResult").innerHTML=`<h2>🎉 Exam Submitted</h2><p>${auto?"Time ended and your exam was submitted automatically.":"Your exam has been submitted successfully."}</p><div class="timerbox">${score} / ${data.questions.length}<br><small>${pct}%</small></div><button class="primary" onclick="showStudent()">Back to Dashboard</button>`;
 refreshHome();
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
refreshHome();
